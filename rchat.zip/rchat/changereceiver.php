<?php
session_start();
$_SESSION['receiver']=$_GET['receiver'];
?>