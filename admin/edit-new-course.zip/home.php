<div class="row">
	<div class="col-lg-6 stretch-card">
		<div class="card">
			<div class="card-body">
				<div class="d-flex justify-content-between align-items-baseline mb-2">
					<h6 class="card-title mb-0">Upcoming Live</h6>
					
				</div>
			  <div class="table-responsive mt-3">
				<table class="table table-hover mb-0">
					<thead>
					<tr>
						<th class="pt-0">Date/time</th>
						<th class="pt-0">Class</th>
						<th class="pt-0">Subject</th>
						<th class="pt-0">Action</th>
					</tr>
					</thead>
					<tbody>
					
						<tr>
							<td>
								<span class="badge badge-danger">Live</span>
							</td>
							<td><span class="badge badge-light">Class 2</span></td>
							<td>Mathematics</td>
							<td>
							
							<a href="live-video.php" class="btn btn-primary btn-sm">VISIT</a>
							
							
							</td>
						</tr>
						<tr>
							<td>
								20 Aug 2020 <br>
								<small class="text-muted">03.00pm to 4.00 pm</small>
							</td>
							<td><span class="badge badge-light">Class 2</span></td>
							<td>Mathematics</td>
							<td>
							
							<a href="add-new-exam.php" class="btn btn-warning btn-icon">
								<i data-feather="eye" class="mt-2"></i>
							</a>
							
							
							</td>
						</tr>
						<tr>
							<td>
								20 Aug 2020 <br>
								<small class="text-muted">03.00pm to 4.00 pm</small>
							</td>
							<td><span class="badge badge-light">Class 2</span></td>
							<td>Mathematics</td>
							<td>
							
							<a href="add-new-exam.php" class="btn btn-warning btn-icon">
								<i data-feather="eye" class="mt-2"></i>
							</a>
							
							
							</td>
						</tr>
						<tr>
							<td>
								20 Aug 2020 <br>
								<small class="text-muted">03.00pm to 4.00 pm</small>
							</td>
							<td><span class="badge badge-light">Class 2</span></td>
							<td>Mathematics</td>
							<td>
							
							<a href="add-new-exam.php" class="btn btn-warning btn-icon">
								<i data-feather="eye" class="mt-2"></i>
							</a>
							
							
							</td>
						</tr>
						<tr>
							<td>
								20 Aug 2020 <br>
								<small class="text-muted">03.00pm to 4.00 pm</small>
							</td>
							<td><span class="badge badge-light">Class 2</span></td>
							<td>Mathematics</td>
							<td>
							
							<a href="add-new-exam.php" class="btn btn-warning btn-icon">
								<i data-feather="eye" class="mt-2"></i>
							</a>
							
							
							</td>
						</tr>
						
						
					
					
					</tbody>
				</table>
				
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-6 stretch-card">
		<div class="card">
			<div class="card-body">
				<div class="d-flex justify-content-between align-items-baseline mb-2">
					<h6 class="card-title mb-0">Upcoming Exam</h6>
					
				</div>
			  <div class="table-responsive mt-3">
				<table class="table table-hover mb-0">
					<thead>
					<tr>
						<th class="pt-0">Date/time</th>
						<th class="pt-0">Class</th>
						<th class="pt-0">Subject</th>
						<th class="pt-0">Action</th>
					</tr>
					</thead>
					<tbody>
					
					<tr>
						<td>
							20 Aug 2020 <br>
							<small class="text-muted">03.00pm to 4.00 pm</small>
						</td>
						<td><span class="badge badge-light">Class 2</span></td>
						<td>Mathematics</td>
						<td>
						
						<a href="add-new-exam.php" class="btn btn-warning btn-icon">
							<i data-feather="eye" class="mt-2"></i>
						</a>
						
						
						</td>
					</tr>
					<tr>
						<td>
							20 Aug 2020 <br>
							<small class="text-muted">03.00pm to 4.00 pm</small>
						</td>
						<td><span class="badge badge-light">Class 2</span></td>
						<td>Mathematics</td>
						<td>
						
						<a href="add-new-exam.php" class="btn btn-warning btn-icon">
							<i data-feather="eye" class="mt-2"></i>
						</a>
						
						
						</td>
					</tr>
					<tr>
						<td>
							20 Aug 2020 <br>
							<small class="text-muted">03.00pm to 4.00 pm</small>
						</td>
						<td><span class="badge badge-light">Class 2</span></td>
						<td>Mathematics</td>
						<td>
						
						<a href="add-new-exam.php" class="btn btn-warning btn-icon">
							<i data-feather="eye" class="mt-2"></i>
						</a>
						
						
						</td>
					</tr>
					<tr>
						<td>
							20 Aug 2020 <br>
							<small class="text-muted">03.00pm to 4.00 pm</small>
						</td>
						<td><span class="badge badge-light">Class 2</span></td>
						<td>Mathematics</td>
						<td>
						
						<a href="add-new-exam.php" class="btn btn-warning btn-icon">
							<i data-feather="eye" class="mt-2"></i>
						</a>
						
						
						</td>
					</tr>
					<tr>
						<td>
							20 Aug 2020 <br>
							<small class="text-muted">03.00pm to 4.00 pm</small>
						</td>
						<td><span class="badge badge-light">Class 2</span></td>
						<td>Mathematics</td>
						<td>
						
						<a href="add-new-exam.php" class="btn btn-warning btn-icon">
							<i data-feather="eye" class="mt-2"></i>
						</a>
						
						
						</td>
					</tr>
					
					
					
					</tbody>
				</table>
				
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'javascript.php'?>