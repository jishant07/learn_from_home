<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Learn From Home</title>
	<!-- core:css -->
	<link rel="stylesheet" href="assets/vendors/core/core.css">
	<!-- endinject -->
  <!-- plugin css for this page -->
	<link rel="stylesheet" href="assets/vendors/prismjs/themes/prism.css">
  <link rel="stylesheet" href="assets/vendors/sweetalert2/sweetalert2.min.css">
  <link rel="stylesheet" href="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
	<!-- endinject -->
  <!-- Layout styles -->  
	<link rel="stylesheet" href="assets/css/demo_1/style.css">
	<link rel="stylesheet" href="assets/css/demo_1/cust.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="assets/images/favicon.png" />
</head>
<body>
	<div class="main-wrapper">

		<?php include('_sidebar.php') ?>
	
		<div class="page-wrapper">
					
			<?php include('_header.php') ?>

			<div class="page-content">
                <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
                    <div>
                        <h4 class="mb-3 mb-md-0">Students</h4>
                    </div>
                    <div class="d-flex align-items-center flex-wrap text-nowrap">
                        
                        <button type="button" class="btn btn-outline-info btn-icon-text mr-2 d-none d-md-block">
                        <i class="btn-icon-prepend" data-feather="download"></i>
                        Import
                        </button>
                    
                        <button type="button" class="btn btn-primary btn-icon-text mr-2 mb-2 mb-md-0 d-none d-md-block">
                        <i class="btn-icon-prepend" data-feather="download-cloud"></i>
                        Download Excel
                        </button>
                        <a href="add-new-student.php" type="button" class="btn btn-success btn-icon-text mb-2 mb-md-0">
                        <i class="btn-icon-prepend" data-feather="plus"></i>
                        Add Student
                        </a>
                    </div>
                </div>

       
                <div class="row">
                    <div class="col-lg-12 stretch-card">
                        <div class="card">
                            <div class="card-body">
                                
                            
                                <div class="table-responsive">
                                <table id="dataTableExample" class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">ID</th>
                                        <th class="pt-0">Created Date</th>
                                        <th class="pt-0">Class</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>ST021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span></td>
                                            <td>
                                                <a href="add-new-student.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>

                                        
                                        
                                    
                                    
                                    </tbody>
                                </table>
                                
                                </div>
                            </div> 
                        </div>
                    </div>
                
                </div> <!-- row -->

			</div>
      
      
		  <?php include('_footer.php') ?>
			
		
		</div>
  </div>
  
      <!-- Modal teacher edit-->
      <div class="modal fade" id="editteacher" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Teacher Name</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="forms-sample">
									
									<div class="form-group">
										<label>Assign Subjects</label>
                    <div class="clearfix"></div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
									</div>
                  <hr>
                  <div class="form-group">
										<label>Class Teacher</label>
                    <div class="clearfix"></div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Make class teacher
											</label>
										</div>
										
									</div>
                                    
								</form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>
       <!-- Modal new teacher-->
      

      <!-- Modal subject -->
      <div class="modal fade" id="editsubject" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Add/Remove Subject</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="forms-sample">
									
									<div class="form-group">
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
									</div>
                  
                                    
								</form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>

	<!-- core:js -->
	<script src="assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="assets/vendors/sweetalert2/sweetalert2.min.js"></script>
  <script src="assets/vendors/promise-polyfill/polyfill.min.js"></script>
  <script src="assets/vendors/datatables/jquery.dataTables.js"></script>
  <script src="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/template.js"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
  <script src="assets/js/sweet-alert.js"></script>
  <script src="assets/js/data-table.js"></script>
  
</html>    