<nav class="sidebar">
      <div class="sidebar-header">
        <a href="#" class="sidebar-brand">
          <img src="assets/images/logo.svg" height="20px" />
        </a>
        <div class="sidebar-toggler not-active">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
      <div class="sidebar-body">
        <ul class="nav">
          <li class="nav-item nav-category">Main</li>
          <li class="nav-item">
            <a href="index.php" class="nav-link">
              <i class="link-icon" data-feather="box"></i>
              <span class="link-title">Dashboard</span>
            </a>
          </li>
		  <li class="nav-item">
            <a href="index.php?action=teachers" class="nav-link">
              <i class="link-icon" data-feather="star"></i>
              <span class="link-title">Teachers</span>
            </a>
          </li>
          <li class="nav-item">
            <a href="index.php?action=students" class="nav-link">
              <i class="link-icon" data-feather="users"></i>
              <span class="link-title">Students</span>
            </a>
          </li>          
          <li class="nav-item nav-category">Classes</li>
		  <?php for($t=0;$t<count($tclasses); $t++) { 
				$classroom = & $tclasses[$t]['classroom'];
		  ?>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#class1" role="button" aria-expanded="false" aria-controls="emails">
              <i class="link-icon" data-feather="folder"></i>
              <span class="link-title">Class 1</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="class1">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="#" class="nav-link">Classroom</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?action=live-sessions&class=<?=$classroom?>" class="nav-link">Live Sessions</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?action=courses&class=<?=$classroom?>" class="nav-link">Courses</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?action=videos&class=<?=$classroom?>" class="nav-link">Videos</a>
                </li>
				<li class="nav-item">
                  <a href="index.php?action=subjects&class=<?=$classroom?>" class="nav-link">Subjects</a>
                </li>
				<li class="nav-item">
                  <a href="index.php?action=books&class=<?=$classroom?>" class="nav-link">Books</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?action=assignments&class=<?=$classroom?>" class="nav-link">Assignments</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?action=exams&class=<?=$classroom?>" class="nav-link">Exams</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?action=documents&class=<?=$classroom?>" class="nav-link">Documents</a>
                </li>
				<li class="nav-item">
                  <a href="index.php?action=classroom-discussion&class=<?=$classroom?>" class="nav-link">Classroom Discussion</a>
                </li>
              </ul>
            </div>
          </li>
		  <?php } ?>		
		</ul>
      </div>
    </nav>