<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Learn From Home</title>
	<!-- core:css -->
	<link rel="stylesheet" href="assets/vendors/core/core.css">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="assets/vendors/sweetalert2/sweetalert2.min.css">
  <link rel="stylesheet" href="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
	<!-- endinject -->
  <!-- Layout styles -->  
	<link rel="stylesheet" href="assets/css/demo_1/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="assets/images/favicon.png" />
</head>
<body>
	<div class="main-wrapper">

		<?php include('_sidebar.php') ?>
	
		<div class="page-wrapper">
					
			<?php include('_header.php') ?>

			<div class="page-content">
        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
          <nav class="page-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Class 1</a></li>
              <li class="breadcrumb-item" aria-current="page"><a href="exams.php">Exams</a></li>
              <li class="breadcrumb-item active" aria-current="page">Date of exam</li>
            </ol>
          </nav>
          
        </div>

        
        <div class="row mb-3">
          <div class="col-lg-12 stretch-card">
            <div class="card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline mb-2">
                  <h6 class="card-title mb-0">Mathematics </h6>
                  
                  
                </div>
                <form class="forms-sample">
									
                  
                  <div class="form-group">
                      <div class="row">
                          <div class="col-md-3 col-12">
                              <label>Date of Exam</label>
                              <input type="text" class="form-control" value="10 Aug 2020" readonly>
                          </div>
                          <div class="col-md-3 col-6">
                              <label>Start Time</label>
                              <input type="text" class="form-control" value="4.00 PM" readonly>
                          </div>
                          <div class="col-md-3 col-6">
                              <label>End Time</label>
                              <input type="text" class="form-control" value="5.00 PM" readonly>
                          </div>
                          <div class="col-md-3 col-6">
                              <label>Total Marks</label>
                              <input type="text" class="form-control" value="40" readonly>
                          </div>
                      </div>
  
                  </div>
                  
								</form>
              </div> 
            </div>
          </div>
        </div> <!-- row -->

        <div class="row">
          <div class="col-lg-12 stretch-card">
            <div class="card">
              <div class="card-body">
                
                
                <div class="table-responsive">
                  <table id="dataTableExample" class="table">
                    <thead>
                      <tr>
                        <th>Student Name</th>
                        <th>Attendance</th>
                        <th>Status</th>
                        <th>Marks</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <div class="mr-3">
                            <img src="https://via.placeholder.com/35x35" class="rounded-circle" alt="user"> Student Name
                          </div>
                         
                        </td>
                        <td><span class="badge badge-pill badge-primary"><i data-feather="x" class="wd-10 ht-10"></i></span></td>
                        <td>-</td>
                        <td></td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>
                          <div class="mr-3">
                            <img src="https://via.placeholder.com/35x35" class="rounded-circle" alt="user"> Student Name
                          </div>
                         
                        </td>
                        <td><span class="badge badge-pill badge-success"><i data-feather="check" class="wd-10 ht-10"></i></span></td>
                        <td><span class="badge badge-info">Not Checked</span></td>
                        <td></td>
                        <td><a href="exam-student-page.php" class="btn btn-danger">OPEN</a></td>
                      </tr>
                      <tr>
                        <td>
                          <div class="mr-3">
                            <img src="https://via.placeholder.com/35x35" class="rounded-circle" alt="user"> Student Name
                          </div>
                         
                        </td>
                        <td><span class="badge badge-pill badge-success"><i data-feather="check" class="wd-10 ht-10"></i></span></td>
                        <td><span class="badge badge-success">Checked</span></td>
                        <td>30</td>
                        <td><a href="exam-student-page.php" class="btn btn-danger">OPEN</a></td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
              </div> 
            </div>
          </div>
        </div> <!-- row -->
        
        

			</div>
      
		  <?php include('_footer.php') ?>
			
		
		</div>
  </div>
  
  

	<!-- core:js -->
	<script src="assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="assets/vendors/datatables/jquery.dataTables.js"></script>
  <script src="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/template.js"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
  <script src="assets/js/data-table.js"></script>
  
</html>    