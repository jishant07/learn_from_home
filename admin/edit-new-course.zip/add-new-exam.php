        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
          <nav class="page-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Class 1</a></li>
              <li class="breadcrumb-item"><a href="exams.php">Exams</a></li>
              <li class="breadcrumb-item active" aria-current="page">Add New Exam</li>
            </ol>
          </nav>
          
        </div>


        <div class="row">
          <div class="col-lg-5 mb-3">
            <div class="card">
              <div class="card-body">
                <form class="forms-sample">
				<div class="form-group">
						<label>Select Question Type</label>
						<select name='selectarea' id='selectarea' class='form-control mb-3'>
						<option value=''>Select type</option>
						<option value='fillblanksection'>fill in the blanks</option>
						<option value='matchsection'>match the following</option>
						<option value='singlechoicesection'>select objective single</option>
						<option value='multiplechoicesection'>select objective multiple</option>					
						<option value='freetextsection'>free text answer</option>
						<option value='uploadimagesection'>upload image or doc</option>						
						</select>
					</div>
										
                  <div class="form-group">
					<label>Schedule Date for Exam</label>
					 <div class="input-group date datepicker" id="datePickerExample">
                      <input type="text" class="form-control"><span class="input-group-addon"><i data-feather="calendar"></i></span>
                    </div>
                  </div>
                  <div class="form-group">
                      <div class="row">
                          <div class="col-6">
                              <label>Start Time</label>
                              <div class="input-group date timepicker" id="datetimepickerExample" data-target-input="nearest">
                                  <input type="text" class="form-control datetimepicker-input" data-target="#datetimepickerExample"/>
                                  <div class="input-group-append" data-target="#datetimepickerExample" data-toggle="datetimepicker">
                                      <div class="input-group-text"><i data-feather="clock"></i></div>
                                  </div>
                              </div>
                          </div>
                          <div class="col-6">
                              <label>End Time</label>
                              <div class="input-group date timepicker" id="datetimepickerExample2" data-target-input="nearest">
                                  <input type="text" class="form-control datetimepicker-input" data-target="#datetimepickerExample2"/>
                                  <div class="input-group-append" data-target="#datetimepickerExample2" data-toggle="datetimepicker">
                                      <div class="input-group-text"><i data-feather="clock"></i></div>
                                  </div>
                              </div>
                          </div>
                      </div>
  
                  </div>
                  <div class="form-group">
                      <div class="row">
                          <div class="col-6">
                              <label>Total Marks</label>
                              <input type="text" class="form-control" value="0" readonly>
                          </div>
                          
                      </div>
  
                  </div>
                  
									
									<button type="submit" class="btn btn-primary mr-2 mt-2">Save</button>
								</form>
               
                
              </div> 
            </div>
          </div>
          <div class="col-lg-7">
            <!--question box-->
            <div class="row mb-3">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
					<form method='post' id='frmfillblank'  autocomplete=off>
	<div id='fillblanksection'>
	<input type='hidden' id='noofblanks' name='noofblanks' value='0'>
		<div class='mdiv1'><h2>Step 3</h2></div>
		<div class='mdiv2'>
			<div><label><div id='showquestion' class='divpadd bold'>Question : <?php if(isset($_SESSION['qcount'])) echo $_SESSION['qcount']+1; else echo '1'?></div> Fill in the blanks</label></div>
			<div class='m10'>
				Question: <input type='text' name='fillblankque' id='fillblankque' class='textbox' />
			</div>
			<div class='m10' id='fillblankansdiv'>				
			</div>
			<div class='m10 asmark'>
				Assign Marks: <input type='text' name='fillblankanswermarks' id='fillblankanswermarks' maxlength=2 size=2 onkeyup="return checkMarks(this.value,this.id)" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false; "/>
				<div id='assignmdiv'>Assign marks on ratio : <input type='checkbox' name='fillmarkratio' value='1'></div>
			</div>
			<div class='m10'><input type='button' name='createfillbankquestion' id='createfillbankquestion' class='button' value="Create Question">				
			</div>			
		</div>
	</div>
	</form>
	<form method='post' id='frmmatch'  autocomplete=off>
	<div id='matchsection'>
		<div class='mdiv1'><h2>Step 3</h2></div>
		<div class='mdiv2'>
			<div id='showquestionmatch' class='divpadd bold'><label>Question : <?php if(isset($_SESSION['qcount'])) echo $_SESSION['qcount']+1; else echo '1'?></label></div> 
			<div class='m10'>Match the following</div>
			<input type='text' name='qmatch' id='qmatch' style='width:548px'>	
			<div class='rowmatch m10'>
				<div class='matchcol'>Column1</div><div class='matchcol'>Column2</div>
			</div>
			<input type='hidden' id='noofmatchrows' name='noofmatchrows' value='3'>
			<div id='matchrows'>
				<div class='rowmatch' id='rowpair1'>
					<div class='matchcol'>Row1 <input type='text' name='matchrowq1' id='matchrowq1' onkeyup="setQuestion(this.value,1)"></div>
					<div class='matchcol'>Row1 <input type='text' name='matchrowopt1' id='matchrowopt1' onkeyup="setAnswer(this.value,1)"></div>
				</div>
				<div class='rowmatch' id='rowpair2'>
					<div class='matchcol'>Row2 <input type='text' name='matchrowq2' id='matchrowq2' onkeyup="setQuestion(this.value,2)"></div>
					<div class='matchcol'>Row2 <input type='text' name='matchrowopt2' id='matchrowopt2' onkeyup="setAnswer(this.value,2)"></div>
				</div>
				<div class='rowmatch'  id='rowpair3'>
					<div class='matchcol'>Row3 <input type='text' name='matchrowq3' id='matchrowq3' onkeyup="setQuestion(this.value,3)"></div>
					<div class='matchcol'>Row3 <input type='text' name='matchrowopt3' id='matchrowopt3' onkeyup="setAnswer(this.value,3)"></div>
				</div>			
			</div>
			<div class='rowmatch'>			
				<div class='matchcol' style='padding-top:20px;'>
				<input type='button' id='addmatchrow' class='button' value='+ Add More Rows'>
				<input type='button' id='removematchrow' class='button' style='display:none' value='- Remove More Rows'>
				</div>				
			</div>
			
			<div id='matchrowans'>
				<div class='rowmatch' style="clear:left;padding-top:30px;"> 
					Answer
				</div>
			<div class='matchcol' style='width:20px;float:left'>
			<ul id="sortno">
					<li id="liq1">1</li>       
					<li id="liq2">2</li>       
					<li id="liq3">3</li>
			</ul>
			</div>
			<div class='matchcol'>
			<ul id="sortable3" class='droptruex' style='margin:auto'>
					<li id="matchq1"></li>       
					<li id="matchq2"></li>       
					<li id="matchq3"></li>       
				
			</ul>
			</div>
			<div class='matchcol' id='swapcols'>
			<ul id="sortable2" class='droptrue'>
				<li><span id='matchrowans_span1'></span><input type=hidden name=matchrowans[] id=matchrowans1></li> 
				<li><span id='matchrowans_span2'></span><input type=hidden name=matchrowans[] id=matchrowans2></li> 
				<li><span id='matchrowans_span3'></span><input type=hidden name=matchrowans[] id=matchrowans3></li>
			</ul>
			</div>
			</div>
			
			<div class='labeldiv asmark'>assign marks <input type='text' name='matchmarks'  id='matchmarks' maxlength=2 size=2 onkeyup="return checkMarks(this.value,this.id)" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;"> 	
			
			</div>
			<input type='button' id='creatematchquestion' class='button' value='Create question'>
		</div>
	</div>
	</form>
	
	<form method='post' id='frmsinglechoice'  autocomplete=off>
	<div id='singlechoicesection'>
		<div class='mdiv1'><h2>Step 3</h2></div>
		<div class='mdiv2'>
			<div id='showquestionsingle' class='divpadd bold'><label>Question : <?php if(isset($_SESSION['qcount'])) echo $_SESSION['qcount']+1; else echo '1'?></label></div> 	
			<input type='hidden' id='noofsinglechoice' name='noofsinglechoice' value='3'>
			<div>Objective type single choice</div>
			<div class='m10'>
				Question: <input type='text' name='singlechoicequestion' id='singlechoicequestion' class='textbox'/>
			</div>
			<div class='mdiv1'>
				Answer
			</div>
			<div class='mdiv2' id='singleanswerchoice'>
				<div class='clrboth m10' id='singleans1'> 
					<div class='left anspadd'>ans1</div> <div class='left'><input type='text' name='singlechoiceans1' id='singlechoiceans1'> </div><div class='left'><input type="radio" id="sinans1" name="singleanswer" value="1" checked></div>				
				</div>
				<div class='clrboth m10' id='singleans2'> 
					<div class='left anspadd'>ans2</div> <div class='left'><input type='text' name='singlechoiceans2' id='singlechoiceans2'> </div><div class='left'><input type="radio" id="sinans2" name="singleanswer" value="2"></div>				
				</div>
				<div class='clrboth m10' id='singleans3'> 
					<div class='left anspadd'>ans3</div> <div class='left'><input type='text' name='singlechoiceans3' id='singlechoiceans3'> </div><div class='left'><input type="radio" id="sinans3" name="singleanswer" value="3"></div>				
				</div>
			</div>
			<div class='rowmatch addchoice' >
				<div class='matchcol'><input type='button' id='addsinglechoice' class='button' value='+ Add More Rows'>
				<input type='button' id='removesinglerow' class='button' style='display:none' value='- Remove More Rows'>
				</div>				
			</div>
			
			<div class=''>
				<div class='labeldiv right' style='width:75%'> 	
				<div class='asmark'>	
				<div class='left anspadd'>assign marks</div> 
				<div class='left anspadd'><input type='text' name='singlemarks' id='singlemarks' maxlength=2 size=2 onkeyup="return checkMarks(this.value,this.id)" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;"></div>
				</div>
				<div class='left anspadd'>
				<input type='button' id='createsinglechoicequestion' class='button' value='Create question'></div>
				</div>			
			</div>
		</div>
	</div>
	</form>
	
	<form method='post' id='frmmultiplechoice'  autocomplete=off>
	<div id='multiplechoicesection'>
		<div class='mdiv1'><h2>Step 3</h2></div>
		<div class='mdiv2'>
			<div id='showquestionmultiple' class='divpadd bold'><label>Question : <?php if(isset($_SESSION['qcount'])) echo $_SESSION['qcount']+1; else echo '1'?></label></div> 
			<input type='hidden' id='noofmultiplechoice' name='noofmultiplechoice' value='3'>
			<div>Objective type multiple choice</div>
			<div class='m10'>
				Question: <input type='text' name='multiplechoicequestion' id='multiplechoicequestion' class='textbox'/>
			</div>
			<div class='mdiv1'>
				Answer
			</div>
			<div class='mdiv2' id='multipleanswerchoice'>
				<div class='clrboth m10' id='multipleans1'> 
					<div class='left anspadd'>ans1</div> <div class='left'><input type='text' name='muloption1' id='muloption1'> </div><div class='left'><input type="checkbox" id="ans1" name="ans1" value="1"></div>				
				</div>
				<div class='clrboth m10' id='multipleans2'> 
					<div class='left anspadd'>ans2</div> <div class='left'><input type='text' name='muloption2' id='muloption2'> </div><div class='left'><input type="checkbox" id="ans2" name="ans2" value="2"></div>				
				</div>
				<div class='clrboth m10' id='multipleans3'> 
					<div class='left anspadd'>ans3</div> <div class='left'><input type='text' name='muloption3' id='muloption3'> </div><div class='left'><input type="checkbox" id="ans3" name="ans3" value="3"></div>				
				</div>
			</div>
			<div class='rowmatch addchoice' >
				<div class='matchcol'><input type='button' id='addmultiplechoice' class='button' value='+ Add More Rows'>
				<input type='button' id='removemultiplerow' class='button' style='display:none' value='- Remove More Rows'>
				</div>				
			</div>
			
			<div class=''>
				<div class='labeldiv right' style='width:75%'> 
				<div class='asmark'>
				<div class='left anspadd'>assign marks</div> 
				<div class='left anspadd'><input type='text' name='multiplemarks' id='multiplemarks' maxlength=2 size=2 onkeyup="return checkMarks(this.value,this.id)" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;"></div> 
				</div>	
				<div class='left anspadd'>
				<input type='button' id='createmultiplechoicequestion' class='button' value='Create question'></div>
				</div>
			</div>	
		</div>
	</div>
	</form>
	
	<form method='post' id='frmfreetext'  autocomplete=off>
	<div id='freetextsection'>
		<div class='mdiv1'><h2>Step 3</h2></div>
		<div class='mdiv2'>
			<div id='showquestionfree' class='divpadd bold'><label>Question : <?php if(isset($_SESSION['qcount'])) echo $_SESSION['qcount']+1; else echo '1'?></label></div> 
			<div>Free text question</div>
			<div class='m10'>
				Question: <input type='text' name='freetextquestion' id='freetextquestion' class='textbox'/>
			</div>
			
			<div class='mdiv2c' id='multipleanswerchoice'>
				<div class='clrboth m10' id='multipleans1'> 
					<div class='left anspadd'>answer </div> <div class='left'>
					<textarea cols=50 rows=4 name='txtanswer' id='txtanswer'></textarea>
					</div>					
				</div>
				<div class='clrboth m10' id='multipleans2'> 
					<div class='left anspadd'>min word limit </div> <div class='left'><input type='text' name='minwords' id='minwords'> </div>
				</div>
				<div class='clrboth m10' id='multipleans3'> 
					<div class='left anspadd'>max word limit </div> <div class='left'><input type='text' name='maxwords' id='maxwords'> </div>				
				</div>
				<div class='clrboth m10' id='multipleans3'> 
					<div class='left anspadd'>apply checker </div> <div class='left'> Match upto </div>
					<div class='left'>
						<select name='matchchecker' id='matchchecker'>
							<option value='100'>100%</option>
							<option value='90'>90%</option>
							<option value='85'>85%</option>
							<option value='80'>80%</option>
							<option value='75'>75%</option>
							<option value='70'>70%</option>
						</select>	
					</div>				
				</div>
			</div>
			
			
			<div class=''>
				<div class='labeldiv' style='width:75%'> 	
					<div class='asmark'>
					<div class='left anspadd'>assign marks</div> 
					<div class='left anspadd'><input type='text' name='freetextmarks' id='freetextmarks' maxlength=2 size=2 onkeyup="return checkMarks(this.value,this.id)" onkeypress="if ( isNaN( String.fromCharCode(event.keyCode) )) return false;"></div>
					<div class='left anspadd'>assign marks on ratio</div> 
					<div class='left anspadd'><input type='checkbox' name='freetxtmarkratio' value='1'></div> 	
					</div>
					<div class='left anspadd'>
						<input type='button' id='createfreetextquestion' class='button' value='Create question'>
					</div>
				</div>
			</div>
		</div>
	</div>
	</form>
	
	<form method='post' id='frmuploadimage'  autocomplete=off>
	<div id='uploadimagesection'>
		<div class='mdiv1'><h2>Step 3</h2></div>
		<div class='mdiv2'>
			<div id='showquestionimg' class='divpadd bold'><label>Question : <?php if(isset($_SESSION['qcount'])) echo $_SESSION['qcount']+1; else echo '1'?></label></div> 
			<div>Submit pic or doc</div>
			<div class='m10'>
				Question: <input type='text' name='uoloadimagequestion' id='uoloadimagequestion' class='textbox'/>
			</div>
			<div class='mdiv1'>
				Answer
			</div>
			<div class='mdiv2' id='multipleanswerchoice'>
				<div class='clrboth m10' id='multipleans1'> 
					<div class='left anspadd'>answer </div> <div class='left'><input type="radio" id="ansimage" name="answerpics" value="image"> </div>	<div class='left anspadd'>image </div>			
				</div>
				<div class='clrboth m10' id='multipleans2'> 
					<div class='left anspadd'>answer </div> <div class='left'><input type="radio" id="ansdoc" name="answerpics" value="doc"> </div>	<div class='left anspadd'>doc </div>			
				</div>				
			</div>			
			<div class=''>
				<div>
				<div class='labeldiv right asmark' style='width:75%'> 	<div class='left anspadd'>assign marks</div> <div class='left anspadd'><input type='text' name='picsmarks' id='picsmarks' maxlength=2 size=2 onkeyup="return checkMarks(this.value,this.id)" onkeypress="if( isNaN( String.fromCharCode(event.keyCode) )) return false;"></div> </div>
				<div class='left anspadd'>
				<input type='button' id='createpicquestion' class='button' value='Create question'></div>
				</div>
			</div>
		</div>
	</div>
	</form>
		
                    <!--form class="forms-sample">
                      
                      <div class="form-group">
                        <div class="row">
                            <div class="col-6">
                                <label class="d-inline-block mt-2 mr-2">Marks</label>
                                <input type="text" class="form-control d-inline-block wd-80" >
                            </div>
                            
                        </div>
    
                      </div>
                      <div class="form-group">
                        <label>Question</label>
                        <input type="text" class="form-control" placeholder="Title">
                      </div>
                      <div class="form-group">
                        <label>Discription</label>
                        <textarea class="form-control" placeholder="Discription" rows="5"></textarea>
                      </div>
                      <div class="form-group">
                        <label>Upload Referance Document</label>
                        <input type="file" name="img[]" class="file-upload-default">
                        <div class="input-group col-xs-12">
                          <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Document">
                          <span class="input-group-append">
                            <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                          </span>
                        </div>
                      </div>
                      <hr>
                      <div class="form-check form-check-flat form-check-primary">
                        <label class="form-check-label">
                          <input type="checkbox" class="form-check-input">
                          Student can upload document
                        </label>
                      </div>
                      
                      
                      <button type="submit" class="btn btn-success mr-2 mt-2">Save</button>
                      <button type="button" class="btn btn-primary btn-icon mt-2" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                          <i data-feather="x"></i>
                      </button>
                    </form-->
                  
                    
                  </div> 
                </div>
              </div>
            </div>
            <!--end question box-->
            <div class="row">
              <div class="col-md-4"></div>
              <div class="col-md-8 col-12">
                <button type="submit" class="btn btn-warning ml-2 d-inline-block float-right">Add Question</button>
                <div class="form-group d-inline-block float-right">
                  <select class="form-control mb-3 ">
                    <option selected>Select Question Type</option>
                    <option value="1">Question & Answer</option>
                    <option value="2">Fill in the blanks</option>
                    <option value="3">Match The Following</option>
                    <option value="4">Checkbox</option>
                    <option value="5">Radio Buttons</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div> <!-- row -->
        
<?php include('javascript.php') ?>

<script>
function reset(){ 
	hideall();
	//$('#questiontypediv').hide();
	//$('#subject').val('0');
	//$('#class').val('0');
	//$('#classroom').val('0');
	//$('#duration').val('0');
	//$('#section').val('0');
	//$('#chapter').val('0');
	//$('#evolution').val('0');
	$('#selectarea').val('0');
	$('#noofsinglechoice').val('3');
	$('#noofmatchrows').val('3');
	$('#noofmultiplechoice').val('3');
 }

$( "#selectarea" ).change(function() {
	hideall()
	let divsec = $('#selectarea').val();
	$('#'+divsec).show();
});

 $( document ).ready(function() {
	reset()
});
 
function hideall(){	
	$('#fillblanksection').hide();
	$('#matchsection').hide();
	$('#singlechoicesection').hide();
	$('#multiplechoicesection').hide();
	$('#freetextsection').hide();
	$('#uploadimagesection').hide();
	$('#noofmatchrows').val(3);
 }
 
</script>