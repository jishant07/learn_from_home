$(function() {
  'use strict';

  $('#myDropify').dropify();
  $('#myDropify2').dropify();
});