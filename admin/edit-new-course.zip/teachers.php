                <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
                    <div>
                        <h4 class="mb-3 mb-md-0">Teachers</h4>
                    </div>
                    <div class="d-flex align-items-center flex-wrap text-nowrap">
                        
                        <button type="button" class="btn btn-outline-info btn-icon-text mr-2 d-none d-md-block">
                        <i class="btn-icon-prepend" data-feather="download"></i>
                        Import
                        </button>
                    
                        <button type="button" class="btn btn-primary btn-icon-text mr-2 mb-2 mb-md-0 d-none d-md-block">
                        <i class="btn-icon-prepend" data-feather="download-cloud"></i>
                        Download Excel
                        </button>
                        <a href="add-new-teacher.php" type="button" class="btn btn-success btn-icon-text mb-2 mb-md-0">
                        <i class="btn-icon-prepend" data-feather="plus"></i>
                        Add New Teacher
                        </a>
                    </div>
                </div>

       
                <div class="row">
                    <div class="col-lg-12 stretch-card">
                        <div class="card">
                            <div class="card-body">
                                
                            
                                <div class="table-responsive">
                                <table id="dataTableExample" class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th class="pt-0">Name</th>
                                        <th class="pt-0">ID</th>
                                        <th class="pt-0">Created Date</th>
                                        <th class="pt-0">Class</th>
                                        <th class="pt-0">Subjects</th>
                                        <th class="pt-0">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <a href="" class="d-flex align-items-center">
                                                <div class="mr-3">
                                                <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-40" alt="user">
                                                </div>
                                                <div class="w-100">
                                                <div class="d-flex justify-content-between">
                                                    <h6 class="text-body mt-1">Jensen Combs</h6>
                                                </div>
                                                </div>
                                            </a>
                                            </td>
                                            <td>TC021029</td>
                                            <td>10 Aug 2020</td>
                                            <td><span class="badge badge-info">Class 1</span> <span class="badge badge-info">Class 2</span></td>
                                            <td><span class="badge badge-light">Subject one</span> <span class="badge badge-light">Subject one</span></td>
                                            <td>
                                                <a href="add-new-teacher.php" class="btn btn-warning btn-icon" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <i data-feather="edit-2" class="mt-2"></i>
                                                </a>
                                                
                                                <button type="button" class="btn btn-primary btn-icon" data-toggle="tooltip" data-placement="top" title="Delete" onclick="showSwal('passing-parameter-execute-cancel')">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        
                                    
                                    
                                    </tbody>
                                </table>
                                
                                </div>
                            </div> 
                        </div>
                    </div>
                
                </div> <!-- row -->
  <?php include('javascript.php') ?>
			
      <!-- Modal teacher edit-->
      <div class="modal fade" id="editteacher" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Teacher Name</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="forms-sample">
									
									<div class="form-group">
										<label>Assign Subjects</label>
                    <div class="clearfix"></div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
									</div>
                  <hr>
                  <div class="form-group">
										<label>Class Teacher</label>
                    <div class="clearfix"></div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Make class teacher
											</label>
										</div>
										
									</div>
                                    
								</form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>
       <!-- Modal new teacher-->
      

      <!-- Modal subject -->
      <div class="modal fade" id="editsubject" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Add/Remove Subject</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="forms-sample">
									
									<div class="form-group">
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
										<div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" checked class="form-check-input">
												Subject Name
											</label>
										</div>
                    <div class="form-check form-check-inline">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input">
												Subject Name
											</label>
										</div>
									</div>
                  
                                    
								</form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>

	