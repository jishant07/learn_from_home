<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
				<p class="text-muted text-center text-md-left">Copyright © <?=date('Y')?> <a href="#" target="_blank">Learn From home</a>. All rights reserved</p>
				<p class="text-muted text-center text-md-left mb-0 d-none d-md-block"><img src="assets/images/amuze_logo.svg" height="20px" /></p>
			</footer>