<?php if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start("ob_gzhandler"); else ob_start(); ?>
<?php
session_start();
error_reporting(E_ALL);
include '../model/config.php';
include 'functions/functions.php';
if(isset($_GET['action']))
$action=$_GET['action'];
else $action='home';

$_SESSION['tid']='1';
$_SESSION['tcode']='t001';
$_SESSION['u_type']='teacher';


switch($action){
	case 'home':		
		$file='home.php';			
	break;
	case 'live-sessions':		
		$live = getLiveSessions($_GET['class'],$_GET['subject']);		
	break;
	case 'edit-new-live-sessions':		
		$video = getVideoInfo($_GET['id']);		
		//print_r($video);
	break;
	case 'video-edit':		
		updateVideo();exit;
	break;
	case 'video-add':		
		addVideo();exit;
	break;
	case 'video-delete':		
		deleteVideo($_GET['id']);exit;
	break;
	case 'live-video':		
		$video = getVideo($_GET['id']);		
	break;
	case 'courses':		
		$courses = getCourses($_GET['class'],$_GET['subject']);		
	break;
	case 'course-delete':		
		deleteCourse($_GET['id']);exit;
	break;
	case 'edit-new-course':		
		$course = getCourse($_GET['id']);
		//print_r($course);	exit;	
	break;
	case 'course-edit':		
		updateCourse();exit;
	break;
	case 'course-add':		
		addCourse();exit;
	break;
	
	case 'videos':	
		$videos = getCourseVideos($_GET['class'],$_GET['subject']);
		//print_r($videos);//exit;	
	break;		
	case 'course-video-delete':		
		//getCourseVideo($_GET['id']);exit;
	break;
	case 'edit-new-video':	
		$video = getCourseVideo($_GET['id']);
		//print_r($video);//exit;	
	break;
	case 'course-video-edit':		
		courseUpdateVideo();exit;
	break;

	case 'course-video-add':		
		courseAddVideo();exit;
	break;
	
	case 'documents':
		$docs = getDocuments($_GET['class'],$_GET['subject']);
	break;
	case 'edit-new-document':
		$doc = getDocument($_GET['id']);
	break;
	
	case 'document-delete':
		deleteDocument($_GET['id']);exit;
	break;
	case 'document-edit':		
		updateDocument();exit;
	break;
	case 'document-add':		
		addDocument();exit;
	break;
		
	case 'assignments':
		$assign = getAssignments($_GET['class'],$_GET['subject']);
	break;

	case 'assignment-add':		
		addAssignment();exit;
	break;
	case 'edit-new-assignment':
		$data = getAssignment($_GET['id'],$_GET['type']);
		//echo'<pre>',print_r($data);exit;
	break;
	case 'assignment-delete':
		deleteAssignment($_GET['id'],$_GET['type']);exit;
	break;		
	case 'assignment-edit':		
		updateAssignment();exit;
	break;

	case 'assignments-student-list':
		$data = getAssignment($_GET['id'],$_GET['type']);
		$stud = getStudentsAssignment($_GET['id'],$_GET['type'],$data['class']);
	break;

	case 'assignments-single-student':
		$data = getAssignmentAnswerByStudent($_GET['id']);		
		$assign = getAssignment($data['question'],str_replace('tbl_','',$data['question_type']));
	break;

	case 'changeStatusAssignment':
	changeStatusAssignment();exit;
	break;
	
	case 'discussion-delete':
		discussionDelete($_GET['id']);
	break;
	case 'classroom-discussion':
		$data = getClassroomDiscussions($_GET['class']);
		
	break;

	case 'single-discussion':
		$data = getClassroomDiscussionById($_GET['id']);
		$comments = getCommentsByDisId($_GET['id']);
		//print_r($data);exit;
	break;

	case 'discussion-feedback':
		discussionFeedback();exit;
	break;
	case 'books':
		$books = my_books();
		//print_r($books);exit;
	break;
	case 'add-new-book':		
	break;
	case 'book-add':
		addBook();exit;
	break;
	case 'edit-book':
		$book = getBook($_GET['id']);
	break;
	case 'books-delete':
		deleteBook($_GET['id']); exit;
	break;
	case 'book-update':
		updateBook();exit;
	break;
	case 'subjects':
		$subjects = getClassSubjects($_GET['class']);	
		//sprint_r($subjects);exit;
	break;
	
	case 'get-subject':
		echo getSubject($_GET['id']);exit;
	break;
	case 'subject-add':
		addSubject();exit;
	break;
	case 'subject-delete':
		deleteSubject($_GET['id']);
	break;
	case 'actionsubject':
	actionsubject();exit;
	break;
	
}

$file="$action.php";	
$tclasses = getTeacherClasses();
$tsubjects = getTeacherSubjectByClasses();
?>

    <?php include('header.php') ?>
    <?php include($file) ?>    
    <?php include('footer.php') ?>

