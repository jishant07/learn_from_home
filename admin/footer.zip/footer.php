</div>
      
		  <?php include('_footer.php') ?>
			
		
		</div>
	</div>

	<!-- core:js -->
	
	<!-- end custom js for this page -->
</body>
</html>    