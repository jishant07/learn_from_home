
    <?php include('header.php') ?>
    <?php include($file) ?>    
    <?php include('footer.php') ?>