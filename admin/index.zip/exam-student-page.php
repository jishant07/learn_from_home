<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Learn From Home</title>
	<!-- core:css -->
	<link rel="stylesheet" href="assets/vendors/core/core.css">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="assets/vendors/sweetalert2/sweetalert2.min.css">
	<link rel="stylesheet" href="assets/vendors/select2/select2.min.css">
	<link rel="stylesheet" href="assets/vendors/jquery-tags-input/jquery.tagsinput.min.css">
	<link rel="stylesheet" href="assets/vendors/dropzone/dropzone.min.css">
	<link rel="stylesheet" href="assets/vendors/dropify/dist/dropify.min.css">
	<link rel="stylesheet" href="assets/vendors/bootstrap-colorpicker/bootstrap-colorpicker.min.css">
	<link rel="stylesheet" href="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
	<link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendors/tempusdominus-bootstrap-4/tempusdominus-bootstrap-4.min.css">
  <link rel="stylesheet" href="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
	<!-- endinject -->
  <!-- Layout styles -->  
	<link rel="stylesheet" href="assets/css/demo_1/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="assets/images/favicon.png" />
</head>
<body>
	<div class="main-wrapper">

		<?php include('_sidebar.php') ?>
	
		<div class="page-wrapper">
					
			<?php include('_header.php') ?>

			<div class="page-content">
        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
          <nav class="page-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Class 1</a></li>
              <li class="breadcrumb-item"><a href="exams.php">Exams</a></li>
              <li class="breadcrumb-item"><a href="exam-student-list.php">Exams Date</a></li>
              <li class="breadcrumb-item active" aria-current="page">Student Name</li>
            </ol>
          </nav>
          
        </div>


        <div class="row">
          <div class="col-lg-12 mb-3">
            <div class="card">
              <div class="card-body">
                <form class="forms-sample">
									
                  <div class="form-group d-inline-block">
									  <div class="mr-5">
                      <img src="https://via.placeholder.com/35x35" class="rounded-circle" alt="user"> Student Name
                    </div>
                    
                  </div>
                  <div class="d-inline-block float-lg-right">
                    <label class="d-inline-block mt-2 mr-2">Marks</label>
                    <input type="text" class="form-control d-inline-block wd-80" value="0" readonly>
                  </div>
                  <hr>
                 
                  
									
									<button type="submit" class="btn btn-primary mr-2 mt-2">Mark As Checked</button>
								</form>
               
                
              </div> 
            </div>
          </div>
          <div class="col-lg-12">
            <!--question box-->
            <div class="row mb-3">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="row">
                      <div class="col-12">
                        <strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-primary" target="_blank">Refereance Document</a>
                      </div>
                      
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-12">
                        <strong>Answer</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-warning" target="_blank">Uploaded Document</a>
                        <form class="mt-4">	
                            <div class="form-group">
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Currect" value="answer">
                                  Currect
                                </label>
                              </div>
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Wrong" value="answer">
                                  Wrong
                                </label>
                              </div>
									          </div>
                            <div class="form-group">
                                <label>Your Feedback</label>
                                <textarea class="form-control" rows="5"></textarea>
                            </div>
                        </form>
                      </div>
                    </div>
                    <hr>
                    <div class="row mt-4">
                        <div class="col-6">
                            <label class="d-inline-block mt-2 mr-2">Marks</label>
                            <input type="text" class="form-control d-inline-block wd-80" >
                            <button type="submit" class="btn btn-success ml-2">Save</button>
                        </div>
                        
                    </div>
                  
                    
                  </div> 
                </div>
              </div>
            </div>
            <!--end question box-->
             <!--question box-->
             <div class="row mb-3">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="row">
                      <div class="col-12">
                        <strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-primary" target="_blank">Refereance Document</a>
                      </div>
                      
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-12">
                        <strong>Answer</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-warning" target="_blank">Uploaded Document</a>
                        <form class="mt-4">	
                            <div class="form-group">
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Currect" value="answer">
                                  Currect
                                </label>
                              </div>
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Wrong" value="answer">
                                  Wrong
                                </label>
                              </div>
									          </div>
                            <div class="form-group">
                                <label>Your Feedback</label>
                                <textarea class="form-control" rows="5"></textarea>
                            </div>
                        </form>
                      </div>
                    </div>
                    <hr>
                    <div class="row mt-4">
                        <div class="col-6">
                            <label class="d-inline-block mt-2 mr-2">Marks</label>
                            <input type="text" class="form-control d-inline-block wd-80" >
                            <button type="submit" class="btn btn-success ml-2">Save</button>
                        </div>
                        
                    </div>
                  
                    
                  </div> 
                </div>
              </div>
            </div>
            <!--end question box-->
             <!--question box-->
             <div class="row mb-3">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="row">
                      <div class="col-12">
                        <strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-primary" target="_blank">Refereance Document</a>
                      </div>
                      
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-12">
                        <strong>Answer</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-warning" target="_blank">Uploaded Document</a>
                        <form class="mt-4">	
                            <div class="form-group">
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Currect" value="answer">
                                  Currect
                                </label>
                              </div>
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Wrong" value="answer">
                                  Wrong
                                </label>
                              </div>
									          </div>
                            <div class="form-group">
                                <label>Your Feedback</label>
                                <textarea class="form-control" rows="5"></textarea>
                            </div>
                        </form>
                      </div>
                    </div>
                    <hr>
                    <div class="row mt-4">
                        <div class="col-6">
                            <label class="d-inline-block mt-2 mr-2">Marks</label>
                            <input type="text" class="form-control d-inline-block wd-80" >
                            <button type="submit" class="btn btn-success ml-2">Save</button>
                        </div>
                        
                    </div>
                  
                    
                  </div> 
                </div>
              </div>
            </div>
            <!--end question box-->
             <!--question box-->
             <div class="row mb-3">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="row">
                      <div class="col-12">
                        <strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-primary" target="_blank">Refereance Document</a>
                      </div>
                      
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-12">
                        <strong>Answer</strong>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam tincidunt erat sapien. Proin vulputate lobortis ex facilisis vulputate. Quisque eu risus tristique arcu pretium pellentesque.</p>
                        <a href="#" class="badge badge-warning" target="_blank">Uploaded Document</a>
                        <form class="mt-4">	
                            <div class="form-group">
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Currect" value="answer">
                                  Currect
                                </label>
                              </div>
                              <div class="form-check form-check-inline">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="optionsRadios5" id="Wrong" value="answer">
                                  Wrong
                                </label>
                              </div>
									          </div>
                            <div class="form-group">
                                <label>Your Feedback</label>
                                <textarea class="form-control" rows="5"></textarea>
                            </div>
                        </form>
                      </div>
                    </div>
                    <hr>
                    <div class="row mt-4">
                        <div class="col-6">
                            <label class="d-inline-block mt-2 mr-2">Marks</label>
                            <input type="text" class="form-control d-inline-block wd-80" >
                            <button type="submit" class="btn btn-success ml-2">Save</button>
                        </div>
                        
                    </div>
                  
                    
                  </div> 
                </div>
              </div>
            </div>
            <!--end question box-->
            
          </div>
        </div> <!-- row -->
        

			</div>
      
		  <?php include('_footer.php') ?>
			
		
		</div>
  </div>
  
  

	<!-- core:js -->
	<script src="assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="assets/vendors/sweetalert2/sweetalert2.min.js"></script>
  <script src="assets/vendors/promise-polyfill/polyfill.min.js"></script>
	<script src="assets/vendors/jquery-validation/jquery.validate.min.js"></script>
	<script src="assets/vendors/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
	<script src="assets/vendors/inputmask/jquery.inputmask.min.js"></script>
	<script src="assets/vendors/select2/select2.min.js"></script>
	<script src="assets/vendors/typeahead.js/typeahead.bundle.min.js"></script>
	<script src="assets/vendors/jquery-tags-input/jquery.tagsinput.min.js"></script>
	<script src="assets/vendors/dropzone/dropzone.min.js"></script>
	<script src="assets/vendors/dropify/dist/dropify.min.js"></script>
	<script src="assets/vendors/bootstrap-colorpicker/bootstrap-colorpicker.min.js"></script>
	<script src="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="assets/vendors/moment/moment.min.js"></script>
	<script src="assets/vendors/tempusdominus-bootstrap-4/tempusdominus-bootstrap-4.js"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/template.js"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
  <script src="assets/js/sweet-alert.js"></script>
  
	<script src="assets/js/form-validation.js"></script>
	<script src="assets/js/bootstrap-maxlength.js"></script>
	<script src="assets/js/inputmask.js"></script>
	<script src="assets/js/select2.js"></script>
	<script src="assets/js/typeahead.js"></script>
	<script src="assets/js/tags-input.js"></script>
	<script src="assets/js/dropzone.js"></script>
	<script src="assets/js/dropify.js"></script>
	<script src="assets/js/bootstrap-colorpicker.js"></script>
	<script src="assets/js/datepicker.js"></script>
	<script src="assets/js/timepicker.js"></script>
  
</html>    