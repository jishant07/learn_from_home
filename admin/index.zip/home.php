<div class="row">
	<div class="col-lg-6 stretch-card">
		<div class="card">
			<div class="card-body">
				<div class="d-flex justify-content-between align-items-baseline mb-2">
					<h6 class="card-title mb-0">Upcoming Live</h6>
					
				</div>
			  <div class="table-responsive mt-3">
				<table class="table table-hover mb-0">
					<thead>
					<tr>
						<th class="pt-0">Date/time</th>
						<th class="pt-0">Class</th>
						<th class="pt-0">Subject</th>
						<th class="pt-0">Action</th>
					</tr>
					</thead>
					<tbody>
					<?php
						for($l=0; $l<count($live); $l++){
							$v = & $live[$l];
							
					?>
						<tr>
							<td>
								<span class="badge badge-danger">Live</span>
							</td>
							<td><span class="badge badge-light"><?=getClassName($v['vid_class'])?></span></td>
							<td><?=$v['subject_name']?></td>
							<td>
							
							<a href="index.php?action=live-video&id=<?=$v['id']?>" class="btn btn-primary btn-sm">VISIT</a>
							
							
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
				
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-6 stretch-card">
		<div class="card">
			<div class="card-body">
				<div class="d-flex justify-content-between align-items-baseline mb-2">
					<h6 class="card-title mb-0">Upcoming Exam</h6>
					
				</div>
			  <div class="table-responsive mt-3">
				<table class="table table-hover mb-0">
					<thead>
					<tr>
						<th class="pt-0">Date/time</th>
						<th class="pt-0">Class</th>
						<th class="pt-0">Subject</th>
						<th class="pt-0">Action</th>
					</tr>
					</thead>
					<tbody>
					<?php
					for($i=0; $i<count($exams); $i++){
						$e = & $exams[$i];
						
					?>
					<tr>
						<td>
							<?=date('d M Y',strtotime($e['opendate']))?> <br>
							<small class="text-muted"><?=date('H:i A',strtotime($e['opendate']))?> to <?=date('H:i A',strtotime($e['closedate']))?></small>
						</td>
						<td><span class="badge badge-light"><?=getClassName($e['classroom'])?></span></td>
						<td><?=getSubject($e['subject'])?></td>
						<td>
						
						<a href="index.php?action=add-new-exam" class="btn btn-warning btn-icon">
							<i data-feather="eye" class="mt-2"></i>
						</a>
						
						
						</td>
					</tr>
					<?php } ?>
					</tbody>
				</table>
				
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'javascript.php'?>