<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Learn From Home</title>
	<!-- core:css -->
	<link rel="stylesheet" href="assets/vendors/core/core.css">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="assets/vendors/sweetalert2/sweetalert2.min.css">
  
	<link rel="stylesheet" href="assets/vendors/dropify/dist/dropify.min.css">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
	<!-- endinject -->
  <!-- Layout styles -->  
	<link rel="stylesheet" href="assets/css/demo_1/style.css">
	<link rel="stylesheet" href="assets/css/demo_1/cust.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="assets/images/favicon.png" />
</head>
<body>
	<div class="main-wrapper">

		<?php include('_sidebar.php') ?>
	
		<div class="page-wrapper">
					
			<?php include('_header.php') ?>

			<div class="page-content">

                <nav class="page-breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="#">Class 1</a></li>
						<li class="breadcrumb-item"><a href="classroom-discussion.php">Classroom Discussion</a></li>
						<li class="breadcrumb-item active" aria-current="page">Start New Discussion</li>
					</ol>
                </nav>
                <div class="row">
					<div class="col-md-6 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
								<form class="forms-sample">
									<div class="form-group">
										<label>Title</label>
										<input type="text" class="form-control" placeholder="Title">
                                    </div>
                                   
									
                                    
                                   
									
									<button type="submit" class="btn btn-primary mr-2 mt-2">Submit</button>
									<button class="btn btn-light mt-2">Cancel</button>
								</form>
                            </div>
                        </div>
					</div>
					
				</div>

        


        

			</div>
      
		  <?php include('_footer.php') ?>
			
		
		</div>
  </div>
  
 

	<!-- core:js -->
	<script src="assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="assets/vendors/sweetalert2/sweetalert2.min.js"></script>
  <script src="assets/vendors/promise-polyfill/polyfill.min.js"></script>
  
	<script src="assets/vendors/dropify/dist/dropify.min.js"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/template.js"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
	<script src="assets/js/dropify.js"></script>
  
</html>    